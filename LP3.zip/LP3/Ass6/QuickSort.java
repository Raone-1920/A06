//Write a program for analysis of quick sort by using deterministic and randomized variant.
public class QuickSort {
    public static void main(String[] args) {
        int[] A = {6, 1, 7, 3, 8, 2, 9, 5, 4};
        System.out.println("Original Array:");
        printArray(A);
        
        quickSort(A, 0, A.length - 1);
        System.out.println("\nSorted Array:");
        printArray(A);
    }

    public static void quickSort(int[] arr, int p, int r) {
        if (p < r) {
            int q = randomPartition(arr, p, r);
            quickSort(arr, p, q - 1);
            quickSort(arr, q + 1, r);
        }
    }

    public static int randomPartition(int[] arr, int p, int r) {
        int i = p + (int)(Math.random() * (r - p + 1));
        swap(arr, i, r);
        return partition(arr, p, r);
    }

    public static int partition(int[] arr, int p, int r) {
        int x = arr[r];
        int i = p - 1;
        for (int j = p; j < r; j++) {
            if (arr[j] <= x) {
                i++;
                swap(arr, i, j);
            }
        }
        swap(arr, i + 1, r);
        return i + 1;
    }

    public static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    public static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}


/*
 Output:
Original Array:
6 1 7 3 8 2 9 5 4 

Sorted Array:
1 2 3 4 5 6 7 8 9 
 */