/* Problem Statement : Write a non-recursive and recursive program to calculate Fibonacci numbers and analyze their
time and space complexity.
*/
import java.util.Scanner;
import java.util.ArrayList;

public class Fibonacci {
    static int iterativeFibonacci(int n) {
        if (n < 0) {
            throw new IllegalArgumentException("Input must be a non-negative integer.");
        }

        ArrayList<Integer> fibList = new ArrayList<>();
        fibList.add(0);
        fibList.add(1);

        for (int i = 2; i <= n; i++) {
            int nextFib = fibList.get(i - 1) + fibList.get(i - 2);
            fibList.add(nextFib);
        }

        return fibList.get(n);
    }

    static int recursiveSteps = 0;

    static int recursiveFibonacci(int n) {
        if (n < 0) {
            throw new IllegalArgumentException("Input must be a non-negative integer.");
        }

        recursiveSteps++;

        if (n <= 1) {
            return n;
        }

        return recursiveFibonacci(n - 1) + recursiveFibonacci(n - 2);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a non-negative number: ");
        int n = scanner.nextInt();

        if (n < 0) {
            System.out.println("Input must be a non-negative integer.");
            return;
        }

        long startTime, endTime;
        long iterativeTime, recursiveTime;

        // Calculate Fibonacci using iteration and measure time
        startTime = System.nanoTime();
        int iterativeResult = iterativeFibonacci(n);
        endTime = System.nanoTime();
        iterativeTime = endTime - startTime;

        // Calculate Fibonacci using recursion and measure time
        startTime = System.nanoTime();
        int recursiveResult = recursiveFibonacci(n);
        endTime = System.nanoTime();
        recursiveTime = endTime - startTime;

        System.out.println("Fibonacci Value: " + recursiveResult);
        System.out.println("Steps required using Iteration: " + iterativeResult);
        System.out.println("Steps required using recursion: " + recursiveSteps);

        // Calculate and print the execution time in nanoseconds
        System.out.println("Execution time for Iterative calculation: " + iterativeTime + " ns");
        System.out.println("Execution time for Recursive calculation: " + recursiveTime + " ns");

        // Test Cases
        // Test Case 1: n = 5
        // Fibonacci Value: 5
        // Steps required using Iteration: 5
        // Steps required using recursion: 9

        // Test Case 2: n = 8
        // Fibonacci Value: 21
        // Steps required using Iteration: 21
        // Steps required using recursion: 41

        // Test Case 3: n = -1 (Exceptional Input)
        // Output: Input must be a non-negative integer.
    }
}
