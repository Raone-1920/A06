// Problem Statement : Write a program to solve a fractional Knapsack problem using a greedy method.
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

class Item {
    int weight;
    int value;

    public Item(int weight, int value) {
        this.weight = weight;
        this.value = value;
    }
}

public class FractionalKnapsack {
    public static double knapsack(int capacity, Item[] items) {
        if (capacity <= 0 || items == null || items.length == 0) {
            throw new IllegalArgumentException("Invalid input: Capacity must be positive, and items should not be empty or null.");
        }

        Arrays.sort(items, Comparator.comparingDouble(item -> -1.0 * item.value / item.weight));

        double maxValue = 0.0;
        int currentWeight = 0;

        for (Item item : items) {
            if (item.weight <= 0 || item.value < 0) {
                throw new IllegalArgumentException("Invalid input: Item weights and values must be non-negative.");
            }

            if (currentWeight + item.weight <= capacity) {
                currentWeight += item.weight;
                maxValue += item.value;
            } else {
                int remainingCapacity = capacity - currentWeight;
                maxValue += (item.value * remainingCapacity) / (double) item.weight;
                break;
            }
        }

        return maxValue;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the knapsack capacity: ");
        int capacity = scanner.nextInt();

        System.out.print("Enter the number of items: ");
        int n = scanner.nextInt();

        Item[] items = new Item[n];

        for (int i = 0; i < n; i++) {
            System.out.println("Enter details for Item " + (i + 1));
            System.out.print("Weight: ");
            int weight = scanner.nextInt();
            System.out.print("Value: ");
            int value = scanner.nextInt();
            items[i] = new Item(weight, value);
        }

        try {
            double maxValue = knapsack(capacity, items);
            System.out.println("Maximum value that can be obtained = " + maxValue);
        } catch (IllegalArgumentException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}

/* 
Output :
Enter the knapsack capacity: 50
Enter the number of items: 3
Enter details for Item 1
Weight: 10
Value: 60
Enter details for Item 2
Weight: 20
Value: 100
Enter details for Item 3
Weight: 30
Value: 120
Maximum value that can be obtained = 240.0
*/ */
