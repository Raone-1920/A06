/*Problem Statement : Write a program to implement Huffman Encoding using a greedy strategy.*/

import java.util.PriorityQueue;
import java.util.Scanner;

class HuffmanNode implements Comparable<HuffmanNode> {
    char data;
    int freq;
    HuffmanNode left, right;

    public HuffmanNode(char data, int freq) {
        this.data = data;
        this.freq = freq;
    }

    @Override
    public int compareTo(HuffmanNode other) {
        return this.freq - other.freq;
    }
}

public class HuffmanCoding {
    public static void printHuffmanCodes(HuffmanNode root, String code) {
        if (root == null) return;

        if (root.data != '$') System.out.println(root.data + ": " + code);

        printHuffmanCodes(root.left, code + "0");
        printHuffmanCodes(root.right, code + "1");
    }

    public static void buildHuffmanTree(char[] data, int[] freq) {
        int n = data.length;
        PriorityQueue<HuffmanNode> minHeap = new PriorityQueue<>();

        for (int i = 0; i < n; i++) minHeap.add(new HuffmanNode(data[i], freq[i]));

        while (minHeap.size() > 1) {
            HuffmanNode left = minHeap.poll();
            HuffmanNode right = minHeap.poll();

            HuffmanNode temp = new HuffmanNode('$', left.freq + right.freq);
            temp.left = left;
            temp.right = right;

            minHeap.add(temp);
        }

        HuffmanNode root = minHeap.poll();
        System.out.println("Huffman Codes:");
        printHuffmanCodes(root, "");
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of characters: ");
        int n = scanner.nextInt();
        char data[] = new char[n];
        int freq[] = new int[n];

        System.out.println("Enter characters and frequencies:");

        for (int i = 0; i < n; i++) {
            data[i] = scanner.next().charAt(0);
            freq[i] = scanner.nextInt();
        }

        buildHuffmanTree(data, freq);
    }
}

/*
Test Case:
s
Enter the number of characters: 7 
Enter characters and frequencies:
a 10
e 15
i 12
o 3
u 4
s 13
t 1



*/
