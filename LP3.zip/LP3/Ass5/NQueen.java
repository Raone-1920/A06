/*Design n-Queens matrix having first Queen placed. Use backtracking to place remaining
Queens to generate the final n-queen‘s matrix.
*/ 
public class NQueen {
    public static void main(String[] args) {
        int n = 4; // Replace with the desired board size

        int[][] board = new int[n][n];

        solveNQueens(board, 0, n);

        System.out.println("--------All possible solutions--------");
    }

    public static void solveNQueens(int[][] board, int x, int n) {
        if (x == n) {
            printBoard(board);
            return;
        }

        for (int col = 0; col < n; col++) {
            if (isSafe(board, x, col, n)) {
                board[x][col] = 1;
                solveNQueens(board, x + 1, n);
                board[x][col] = 0;
            }
        }
    }

    public static boolean isSafe(int[][] board, int x, int y, int n) {
        for (int row = 0; row < x; row++) {
            if (board[row][y] == 1) {
                return false;
            }
        }

        int row = x;
        int col = y;
        while (row >= 0 && col >= 0) {
            if (board[row][col] == 1) {
                return false;
            }
            row--;
            col--;
        }

        row = x;
        col = y;
        while (row >= 0 && col < n) {
            if (board[row][col] == 1) {
                return false;
            }
            row--;
            col++;
        }

        return true;
    }

    public static void printBoard(int[][] board) {
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                if (board[i][j] == 1) {
                    System.out.print("[Q]");
                } else {
                    System.out.print("[]");
                }
            }
            System.out.println();
        }
        System.out.println();
        System.out.println();
    }
}

/*
 Output:
[][Q][][]
[][][][Q]
[Q][][][]
[][][Q][]


[][][Q][]
[Q][][][]
[][][][Q]
[][Q][][]

--------All possible solutions--------
*/